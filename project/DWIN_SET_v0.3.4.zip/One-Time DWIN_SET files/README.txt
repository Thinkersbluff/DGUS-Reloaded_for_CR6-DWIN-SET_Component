Each of these files needs only to be flashed once to the display.  
It is NOT necessary to install either of them again, at each new release. (Unless stated otherwise in the release notes.)

WARNING: IF you decide to flash back to the Marlin CR6 Community Firmware, you WILL need to flash their T5L....cfg file (not this one) before their UI will work correctly.

The HZK file (Font 0 database) is compatible with either the Klipper or the Marlin CR6Community Firmware.

   Always flash the most recent .HZK file
   Strip everything after K, to rename the file before flashing it.

